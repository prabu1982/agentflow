"""
LangGraph multi-agent flow.

  START → MainAgent (parse JSON: agent, steps, next_agent)
       → Web Agent OR Desktop Agent
       → if output is array and next_agent set → next_agent_batch (run next_agent per item, collect)
       → END

  SQLite: step logging + checkpoint for crash recovery.
"""

import json
from typing import Any, Literal

from langgraph.graph import END, START, StateGraph
from langgraph.checkpoint.sqlite import SqliteSaver

from agents.main_agent import MainAgent
from agents.desktop_agent import DesktopAgent
from agents.web_agent import WebAgent
from state import AgentState
from db import log_step, update_execution_status

# Agent instances
main_agent = MainAgent()
desktop_agent = DesktopAgent(default_count=3)
web_agent = WebAgent()

# Checkpointer for crash recovery
import sqlite3
from pathlib import Path
_db_path = Path(__file__).parent / "langgraph.db"
_checkpoint_conn = sqlite3.connect(str(_db_path), check_same_thread=False)
checkpointer = SqliteSaver(_checkpoint_conn)


def _log(execution_id: str, step_index: int, node: str, status: str, inp: Any = None, out: Any = None, err: str = None):
    if execution_id:
        log_step(execution_id, step_index, node, status, inp, out, err)


def main_agent_node(state: AgentState) -> dict:
    """Read input JSON and determine which sub-agent to call."""
    execution_id = state.get("execution_id", "")
    step_idx = state.get("step_index", 0)

    input_json = state.get("input_json")
    if input_json is None:
        _log(execution_id, step_idx, "main_agent", "failed", None, None, "Missing input_json")
        return {
            "error": "Missing input_json",
            "execution_history": [{"node": "main_agent", "status": "error", "error": "Missing input_json"}],
        }

    _log(execution_id, step_idx, "main_agent", "started", {"input_json": input_json})

    parsed = main_agent.parse_input(input_json)

    if parsed.get("error"):
        _log(execution_id, step_idx, "main_agent", "failed", None, None, parsed["error"])
        return {
            "error": parsed["error"],
            "execution_history": [{"node": "main_agent", "status": "error", "error": parsed["error"]}],
        }

    out = {
        "agent": parsed["agent"],
        "steps": parsed["steps"],
        "next_agent": parsed.get("next_agent"),
        "next_steps": parsed.get("next_steps", [{"action": "process"}]),
        "context": parsed.get("context", {}),
        "execution_history": [{"node": "main_agent", "status": "parsed", "agent": parsed["agent"]}],
    }
    _log(execution_id, step_idx, "main_agent", "completed", None, {"agent": parsed["agent"], "next_agent": parsed.get("next_agent")})
    return out


def route_to_sub_agent(state: AgentState) -> Literal["web_agent", "desktop_agent", "__end__"]:
    if state.get("error"):
        return "__end__"
    agent = state.get("agent", "")
    if agent == "web":
        return "web_agent"
    if agent == "desktop":
        return "desktop_agent"
    return "__end__"


def web_agent_node(state: AgentState) -> dict:
    """Run Web Agent with steps from JSON."""
    execution_id = state.get("execution_id", "")
    step_idx = state.get("step_index", 1)
    steps = state.get("steps", [])
    context = state.get("context", {})

    _log(execution_id, step_idx, "web_agent", "started", {"steps": steps})

    if not steps:
        steps = [{"action": "process"}]
    result = web_agent.execute(steps, input_item=context.get("input_item"), context=context)

    out = {
        "web_output": result,
        "execution_history": [{"node": "web_agent", "status": "ok", "output_keys": list(result.keys())}],
    }
    _log(execution_id, step_idx, "web_agent", "completed", None, {"output_keys": list(result.keys())})
    return out


def desktop_agent_node(state: AgentState) -> dict:
    """Run Desktop Agent with steps from JSON."""
    execution_id = state.get("execution_id", "")
    step_idx = state.get("step_index", 1)
    steps = state.get("steps", [])
    context = state.get("context", {})

    _log(execution_id, step_idx, "desktop_agent", "started", {"steps": steps})

    if not steps:
        steps = [{"action": "default", "count": 3}]
    output = desktop_agent.execute(steps, context)

    out = {
        "desktop_output": output,
        "execution_history": [{"node": "desktop_agent", "status": "ok", "output_count": len(output)}],
    }
    _log(execution_id, step_idx, "desktop_agent", "completed", None, {"output_count": len(output)})
    return out


def _get_source_array(state: AgentState) -> tuple[list[Any] | None, str]:
    """Get array from first agent output. Returns (array, source_key) or (None, '')."""
    desktop = state.get("desktop_output")
    web = state.get("web_output")
    if isinstance(desktop, list) and len(desktop) > 0:
        return desktop, "desktop_output"
    if isinstance(web, list) and len(web) > 0:
        return web, "web_output"
    if isinstance(web, dict) and isinstance(web.get("output"), list) and len(web.get("output", [])) > 0:
        return web["output"], "web_output.output"
    return None, ""


def route_after_first_agent(state: AgentState) -> Literal["next_agent_batch", "__end__"]:
    """If first agent returned array and next_agent is set → run next_agent for each item."""
    if state.get("error"):
        return "__end__"
    arr, _ = _get_source_array(state)
    next_agent = state.get("next_agent")
    if arr and next_agent:
        return "next_agent_batch"
    return "__end__"


def next_agent_batch_node(state: AgentState) -> dict:
    """
    Run next_agent for each item in the array, collect responses, set final_output.
    """
    execution_id = state.get("execution_id", "")
    step_idx = state.get("step_index", 2)
    arr, _ = _get_source_array(state)
    next_agent = state.get("next_agent", "")
    next_steps = state.get("next_steps", [{"action": "process"}])
    context = state.get("context", {})

    if not arr:
        _log(execution_id, step_idx, "next_agent_batch", "completed", None, {"collected": 0})
        return {"final_output": [], "execution_history": [{"node": "next_agent_batch", "collected": 0}]}

    _log(execution_id, step_idx, "next_agent_batch", "started", {"item_count": len(arr), "next_agent": next_agent})

    collected = []
    for i, item in enumerate(arr):
        if next_agent == "web":
            res = web_agent.execute(next_steps, input_item=item, context={**context, "item_index": i})
        else:
            res = desktop_agent.execute(next_steps, context={**context, "input_item": item, "item_index": i})
        collected.append(res)

    out = {
        "collected_outputs": collected,
        "final_output": collected,
        "execution_history": [{"node": "next_agent_batch", "invocations": len(collected), "next_agent": next_agent}],
    }
    _log(execution_id, step_idx, "next_agent_batch", "completed", None, {"collected_count": len(collected)})
    return out


def build_graph(use_checkpointer: bool = True):
    """Build and compile the LangGraph workflow."""
    graph = StateGraph(AgentState)

    graph.add_node("main_agent", main_agent_node)
    graph.add_node("web_agent", web_agent_node)
    graph.add_node("desktop_agent", desktop_agent_node)
    graph.add_node("next_agent_batch", next_agent_batch_node)

    graph.add_edge(START, "main_agent")
    graph.add_conditional_edges(
        "main_agent",
        route_to_sub_agent,
        {"web_agent": "web_agent", "desktop_agent": "desktop_agent", "__end__": END},
    )
    graph.add_conditional_edges(
        "web_agent",
        route_after_first_agent,
        {"next_agent_batch": "next_agent_batch", "__end__": END},
    )
    graph.add_conditional_edges(
        "desktop_agent",
        route_after_first_agent,
        {"next_agent_batch": "next_agent_batch", "__end__": END},
    )
    graph.add_edge("next_agent_batch", END)

    if use_checkpointer:
        return graph.compile(checkpointer=checkpointer)
    return graph.compile()


def run(
    input_json: dict | str,
    execution_id: str | None = None,
    resume: bool = False,
) -> dict:
    """
    Run the multi-agent workflow.

    Args:
        input_json: JSON with agent, steps, optional next_agent, next_steps.
        execution_id: Unique id for this run (for logging and resume). Auto-generated if None.
        resume: If True, resume from last checkpoint for execution_id (ignores input_json for new input).

    Returns:
        Final state with web_output, desktop_output, final_output, execution_history.
    """
    import uuid
    exec_id = execution_id or str(uuid.uuid4())
    thread_id = exec_id

    from db import create_execution, get_execution

    app = build_graph(use_checkpointer=True)
    config = {"configurable": {"thread_id": thread_id}}

    if resume:
        exec_rec = get_execution(exec_id)
        if not exec_rec:
            return {"error": f"No execution found for id: {exec_id}", "execution_id": exec_id}
        # Resume: invoke with no input to continue from checkpoint
        result = app.invoke(None, config=config)
    else:
        create_execution(exec_id, input_json, thread_id)
        initial: AgentState = {
            "input_json": input_json,
            "execution_id": exec_id,
            "step_index": 0,
            "execution_history": [],
        }
        try:
            result = app.invoke(initial, config=config)
        except Exception as e:
            update_execution_status(exec_id, "failed")
            raise

    update_execution_status(exec_id, "completed")
    result["execution_id"] = exec_id
    return result
