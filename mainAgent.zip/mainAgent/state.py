"""State schema for the LangGraph multi-agent workflow."""

import operator
from typing import Annotated, Any, List, Optional
from typing_extensions import TypedDict


class AgentState(TypedDict, total=False):
    """State shared across MainAgent and sub-agents (Web, Desktop)."""

    # Execution tracking
    execution_id: str  # For DB logging and resume
    step_index: int  # Current step index for logging

    # Input (from user JSON)
    input_json: Any  # Raw JSON dict or str
    agent: str  # "web" | "desktop" - which sub-agent to run
    steps: List[dict]  # Steps to execute
    next_agent: Optional[str]  # When first agent returns array, run this for each item
    next_steps: List[dict]  # Steps for next_agent
    context: dict  # Optional context for agents

    # Intermediate: array from first agent (for fan-out)
    source_output: List[Any]  # Array from Desktop or Web to iterate over
    collected_outputs: List[Any]  # Results from next_agent per item

    # Outputs
    desktop_output: Optional[List[Any]]  # Result from Desktop Agent
    web_output: Optional[Any]  # Result from Web Agent
    final_output: Any  # Combined output after next_agent batch (if used)
    execution_history: Annotated[List[dict], operator.add]  # Audit trail
    error: Optional[str]
