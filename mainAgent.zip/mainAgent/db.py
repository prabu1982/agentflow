"""SQLite database for execution tracking, step logging, and crash recovery."""

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

DB_PATH = Path(__file__).parent / "langgraph.db"


def _default_serializer(obj: Any) -> str:
    if isinstance(obj, (dict, list)):
        return json.dumps(obj, default=str)
    return str(obj)


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    """Create tables if they don't exist."""
    with get_conn() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS executions (
                id TEXT PRIMARY KEY,
                input_json TEXT,
                status TEXT NOT NULL DEFAULT 'running',
                thread_id TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS steps_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                execution_id TEXT NOT NULL,
                step_index INTEGER NOT NULL,
                node_name TEXT NOT NULL,
                status TEXT NOT NULL,
                input_summary TEXT,
                output_summary TEXT,
                error TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (execution_id) REFERENCES executions(id)
            );
            CREATE INDEX IF NOT EXISTS idx_steps_execution ON steps_log(execution_id);
        """)


def create_execution(execution_id: str, input_json: dict | str, thread_id: str) -> None:
    """Record a new execution."""
    now = datetime.utcnow().isoformat()
    inp = json.dumps(input_json, default=str) if not isinstance(input_json, str) else input_json
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO executions (id, input_json, status, thread_id, created_at, updated_at) VALUES (?, ?, 'running', ?, ?, ?)",
            (execution_id, inp, thread_id, now, now),
        )


def update_execution_status(execution_id: str, status: str) -> None:
    """Update execution status (running, completed, failed)."""
    now = datetime.utcnow().isoformat()
    with get_conn() as conn:
        conn.execute(
            "UPDATE executions SET status = ?, updated_at = ? WHERE id = ?",
            (status, now, execution_id),
        )


def log_step(
    execution_id: str,
    step_index: int,
    node_name: str,
    status: str,
    input_summary: Any = None,
    output_summary: Any = None,
    error: Optional[str] = None,
) -> None:
    """Log a step (started, completed, failed)."""
    now = datetime.utcnow().isoformat()
    inp = _default_serializer(input_summary)
    out = _default_serializer(output_summary) if output_summary is not None else None
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO steps_log (execution_id, step_index, node_name, status, input_summary, output_summary, error, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (execution_id, step_index, node_name, status, inp, out, error, now),
        )


def get_last_completed_step(execution_id: str) -> Optional[dict]:
    """Get the last successfully completed step for an execution. Used for resume."""
    with get_conn() as conn:
        row = conn.execute(
            """SELECT step_index, node_name, output_summary FROM steps_log
               WHERE execution_id = ? AND status = 'completed'
               ORDER BY step_index DESC LIMIT 1""",
            (execution_id,),
        ).fetchone()
    if row:
        return {"step_index": row["step_index"], "node_name": row["node_name"], "output_summary": row["output_summary"]}
    return None


def get_pending_execution() -> Optional[dict]:
    """Get the most recent pending (running) execution from DB. Used for auto-resume on startup."""
    with get_conn() as conn:
        row = conn.execute(
            """SELECT id, input_json, status, thread_id, created_at, updated_at
               FROM executions WHERE status = 'running'
               ORDER BY updated_at DESC LIMIT 1""",
        ).fetchone()
    if row:
        return dict(row)
    return None


def get_execution(execution_id: str) -> Optional[dict]:
    """Get execution record by id."""
    with get_conn() as conn:
        row = conn.execute(
            "SELECT id, input_json, status, thread_id, created_at FROM executions WHERE id = ?",
            (execution_id,),
        ).fetchone()
    if row:
        return dict(row)
    return None


def get_steps(execution_id: str) -> list:
    """Get all steps for an execution."""
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT step_index, node_name, status, input_summary, output_summary, error, created_at FROM steps_log WHERE execution_id = ? ORDER BY step_index",
            (execution_id,),
        ).fetchall()
    return [dict(r) for r in rows]


# Ensure DB is initialized on import
init_db()
