"""Main Agent - Reads input JSON and routes to Web or Desktop sub-agent."""

import json
from typing import Any, Dict, List


class MainAgent:
    """
    Orchestrator agent. Receives JSON with:
    - agent: "web" | "desktop" (or core_agent)
    - steps: list of step definitions to execute
    - next_agent: (optional) when first agent returns array, run this for each item
    - next_steps: (optional) steps for next_agent; if missing uses context.web_steps or [{"action": "process"}]
    - context: optional dict for sub-agents
    """

    SUPPORTED_AGENTS = {"web", "desktop"}

    def parse_input(self, input_data: str | dict) -> Dict[str, Any]:
        """
        Parse input JSON into agent, steps, next_agent, next_steps, context.

        Expected JSON:
        {
            "agent": "desktop" | "web",
            "steps": [{"action": "...", ...}],
            "next_agent": "web" | "desktop",  // optional: run when first agent returns array
            "next_steps": [{"action": "..."}], // optional: steps for next_agent
            "context": {}
        }

        Returns:
            Dict with agent, steps, next_agent, next_steps, context; or error if invalid.
        """
        if isinstance(input_data, str):
            try:
                data = json.loads(input_data)
            except json.JSONDecodeError as e:
                return {
                    "error": f"Invalid JSON: {e}",
                    "agent": None,
                    "steps": [],
                    "next_agent": None,
                    "next_steps": [],
                    "context": {},
                }
        else:
            data = input_data or {}

        agent = (data.get("agent") or data.get("core_agent") or "").lower().strip()
        if agent not in self.SUPPORTED_AGENTS:
            return {
                "error": f"Unsupported agent: '{agent}'. Use 'web' or 'desktop'.",
                "agent": agent or None,
                "steps": data.get("steps", []),
                "next_agent": None,
                "next_steps": [],
                "context": data.get("context", {}),
            }

        next_agent_raw = data.get("next_agent", "").lower().strip() or None
        next_agent = next_agent_raw if next_agent_raw in self.SUPPORTED_AGENTS else None
        next_steps: List[dict] = data.get("next_steps") or data.get("context", {}).get("web_steps") or [{"action": "process"}]

        return {
            "agent": agent,
            "steps": data.get("steps", []),
            "next_agent": next_agent,
            "next_steps": next_steps,
            "context": data.get("context", {}),
            "error": None,
        }
