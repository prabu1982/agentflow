"""Sub-agents: Main (orchestrator), Web, Desktop."""

from .main_agent import MainAgent
from .desktop_agent import DesktopAgent
from .web_agent import WebAgent

__all__ = ["MainAgent", "DesktopAgent", "WebAgent"]
