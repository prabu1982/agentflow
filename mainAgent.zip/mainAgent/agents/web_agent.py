"""Web Agent - Executes web automation steps."""

from typing import Any, List


class WebAgent:
    """Sub-agent for web automation. Runs steps for a single input/item."""

    def execute(
        self,
        steps: List[dict],
        input_item: Any = None,
        context: dict | None = None,
    ) -> dict:
        """
        Execute web steps. In production: navigate, fill forms, extract data.

        Args:
            steps: List of step definitions, e.g. [{"action": "navigate", "url": "..."}]
            input_item: Optional single item (e.g. from Desktop Agent).
            context: Optional context from MainAgent.

        Returns:
            Dict with result of execution.
        """
        context = context or {}
        result = {
            "agent": "web",
            "input_item": input_item,
            "steps_executed": len(steps),
            "output": None,
        }

        for i, step in enumerate(steps):
            action = step.get("action", "process")
            if action == "navigate":
                result["output"] = {
                    "url": step.get("url", "https://example.com"),
                    "status": "navigated",
                }
            elif action == "fill_form":
                result["output"] = {
                    "form_filled": True,
                    "field": step.get("field", "default"),
                }
            elif action == "extract":
                result["output"] = {
                    "extracted": f"data_for_{input_item}",
                }
            else:
                result["output"] = {
                    "processed": True,
                    "step_index": i,
                    "action": action,
                }

        return result
