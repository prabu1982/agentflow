"""Desktop Agent - Executes desktop automation steps and returns a list of results."""

from typing import Any, List


class DesktopAgent:
    """Sub-agent for desktop automation. Returns an array of elements."""

    def __init__(self, default_count: int = 3):
        self.default_count = default_count

    def execute(self, steps: List[dict], context: dict | None = None) -> List[Any]:
        """
        Execute desktop steps. In production: list files, get windows, clipboard, etc.

        Args:
            steps: List of step definitions, e.g. [{"action": "list_files", "count": 3}]
            context: Optional context from MainAgent.

        Returns:
            List of results (e.g. file paths, window handles).
        """
        context = context or {}
        results: List[Any] = []

        for i, step in enumerate(steps):
            action = step.get("action", "default")
            count = step.get("count", self.default_count)
            if action == "list_files":
                path = step.get("path", ".")
                results = [
                    {"path": f"{path}/file_{j}.txt", "index": j}
                    for j in range(count)
                ]
            elif action == "get_windows":
                results = [
                    {"window_id": j, "title": f"Window_{j}"}
                    for j in range(count)
                ]
            else:
                results = [
                    {"value": f"desktop_output_{j}", "step_index": i, "item_index": j}
                    for j in range(count)
                ]

        return results
