"""Run the LangGraph multi-agent flow. Supports auto-resume from pending executions in SQLite."""

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from graph import run
from db import get_execution, get_steps, get_pending_execution


def main():
    parser = argparse.ArgumentParser(description="LangGraph multi-agent flow")
    parser.add_argument("input", nargs="?", help="JSON file or omit for default example")
    parser.add_argument(
        "--resume", "-r",
        metavar="EXEC_ID",
        help="Resume a specific execution by ID (overrides auto-resume)",
    )
    parser.add_argument(
        "--exec-id", metavar="ID",
        help="Use specific execution ID for a new run (for resume later)",
    )
    parser.add_argument(
        "--no-resume",
        action="store_true",
        help="Do not auto-resume pending execution; always start a new run",
    )
    parser.add_argument(
        "--steps",
        action="store_true",
        help="Show steps from DB for an execution (input = EXEC_ID)",
    )
    args = parser.parse_args()

    if args.resume:
        exec_id = args.resume
        rec = get_execution(exec_id)
        if not rec:
            print(f"Error: No execution found for id: {exec_id}")
            sys.exit(1)
        print(f"Resuming execution {exec_id}...")
        result = run(None, execution_id=exec_id, resume=True)
    elif args.steps and args.input:
        steps = get_steps(args.input)
        print(json.dumps(steps, indent=2, default=str))
        return
    else:
        # On startup: check SQLite for pending execution and auto-resume if found
        pending = None if args.no_resume else get_pending_execution()
        if pending:
            exec_id = pending["id"]
            print(f"Found pending execution in DB: {exec_id}")
            print("Resuming from where it left off...\n")
            result = run(None, execution_id=exec_id, resume=True)
        else:
            if args.input and args.input.endswith(".json"):
                with open(args.input) as f:
                    input_json = json.load(f)
            else:
                input_json = {
                    "agent": "desktop",
                    "steps": [{"action": "list_files", "path": "/tmp", "count": 3}],
                    "context": {},
                }
            if not args.input:
                print("Using default example. Pass a .json file or see example_desktop_next_agent.json\n")
            print("Input:", json.dumps(input_json, indent=2))
            print("\nRunning multi-agent flow...\n")
            result = run(input_json, execution_id=args.exec_id)

    if result.get("error") and "No execution found" in str(result.get("error", "")):
        print("Error:", result["error"])
        sys.exit(1)

    print("Result:")
    out = {k: v for k, v in result.items() if v is not None}
    print(json.dumps(out, indent=2, default=str))
    if result.get("execution_id"):
        print(f"\nExecution ID: {result['execution_id']}")
        print("To resume after crash: python main.py --resume", result["execution_id"])


if __name__ == "__main__":
    main()
