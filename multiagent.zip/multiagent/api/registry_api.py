"""Agent Registry API: register and list agents (base_url, etc.)."""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel

from models.db_models import get_async_session, AgentRegistryModel
from db import get_agent_by_id, list_agents, register_agent, update_agent, delete_agent


router = APIRouter(prefix="/registry", tags=["Agent Registry"])


class AgentRegisterRequest(BaseModel):
    agent_id: str
    name: str
    base_url: str
    description: str = ""
    capabilities: dict = {}
    metadata: dict = {}


class AgentUpdateRequest(BaseModel):
    name: Optional[str] = None
    base_url: Optional[str] = None
    description: Optional[str] = None
    capabilities: Optional[dict] = None


class AgentResponse(BaseModel):
    agent_id: str
    name: str
    base_url: str
    description: str
    capabilities: dict
    metadata: dict

    @classmethod
    def from_model(cls, m: AgentRegistryModel) -> "AgentResponse":
        return cls(
            agent_id=m.agent_id,
            name=m.name,
            base_url=m.base_url,
            description=m.description or "",
            capabilities=m.capabilities or {},
            metadata=m.metadata_ or {},
        )


@router.post("/agents", response_model=AgentResponse)
async def register_agent_endpoint(
    body: AgentRegisterRequest,
    session: AsyncSession = Depends(get_async_session),
):
    """Register or upsert an agent. Uses agent_id as key."""
    agent = await register_agent(
        session,
        agent_id=body.agent_id,
        name=body.name,
        base_url=body.base_url,
        description=body.description,
        capabilities=body.capabilities,
        metadata_=body.metadata,
    )
    return AgentResponse.from_model(agent)


@router.get("/agents", response_model=list[AgentResponse])
async def list_agents_endpoint(session: AsyncSession = Depends(get_async_session)):
    """List all registered agents."""
    agents = await list_agents(session)
    return [AgentResponse.from_model(a) for a in agents]


@router.get("/agents/{agent_id}", response_model=AgentResponse)
async def get_agent_endpoint(
    agent_id: str,
    session: AsyncSession = Depends(get_async_session),
):
    """Get agent by agent_id."""
    agent = await get_agent_by_id(session, agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_id}' not found")
    return AgentResponse.from_model(agent)


@router.patch("/agents/{agent_id}", response_model=AgentResponse)
async def update_agent_endpoint(
    agent_id: str,
    body: AgentUpdateRequest,
    session: AsyncSession = Depends(get_async_session),
):
    """Update an existing agent."""
    agent = await update_agent(
        session,
        agent_id,
        name=body.name,
        base_url=body.base_url,
        description=body.description,
        capabilities=body.capabilities,
    )
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_id}' not found")
    return AgentResponse.from_model(agent)


@router.delete("/agents/{agent_id}", status_code=204)
async def delete_agent_endpoint(
    agent_id: str,
    session: AsyncSession = Depends(get_async_session),
):
    """Delete an agent."""
    ok = await delete_agent(session, agent_id)
    if not ok:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_id}' not found")
