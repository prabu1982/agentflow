"""Agent registry CRUD using database."""
from typing import Optional
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from models.db_models import AgentRegistryModel


async def get_agent_by_id(session: AsyncSession, agent_id: str) -> Optional[AgentRegistryModel]:
    """Get agent by agent_id (e.g. WEB, DESKTOP)."""
    r = await session.execute(select(AgentRegistryModel).where(AgentRegistryModel.agent_id == agent_id))
    return r.scalar_one_or_none()


async def list_agents(session: AsyncSession) -> list[AgentRegistryModel]:
    """List all registered agents."""
    r = await session.execute(select(AgentRegistryModel).order_by(AgentRegistryModel.agent_id))
    return list(r.scalars().all())


async def register_agent(
    session: AsyncSession,
    agent_id: str,
    name: str,
    base_url: str,
    description: str = "",
    capabilities: Optional[dict] = None,
    metadata_: Optional[dict] = None,
) -> AgentRegistryModel:
    """Register or update an agent."""
    existing = await get_agent_by_id(session, agent_id)
    if existing:
        existing.name = name
        existing.base_url = base_url
        existing.description = description or existing.description
        if capabilities is not None:
            existing.capabilities = capabilities
        if metadata_ is not None:
            existing.metadata_ = metadata_
        await session.flush()
        await session.refresh(existing)
        return existing
    agent = AgentRegistryModel(
        agent_id=agent_id,
        name=name,
        base_url=base_url,
        description=description,
        capabilities=capabilities or {},
        metadata_=metadata_ or {},
    )
    session.add(agent)
    await session.flush()
    await session.refresh(agent)
    return agent


async def update_agent(
    session: AsyncSession,
    agent_id: str,
    name: Optional[str] = None,
    base_url: Optional[str] = None,
    description: Optional[str] = None,
    capabilities: Optional[dict] = None,
) -> Optional[AgentRegistryModel]:
    """Update an existing agent."""
    agent = await get_agent_by_id(session, agent_id)
    if not agent:
        return None
    if name is not None:
        agent.name = name
    if base_url is not None:
        agent.base_url = base_url
    if description is not None:
        agent.description = description
    if capabilities is not None:
        agent.capabilities = capabilities
    await session.flush()
    await session.refresh(agent)
    return agent


async def delete_agent(session: AsyncSession, agent_id: str) -> bool:
    """Delete agent by agent_id. Returns True if deleted."""
    agent = await get_agent_by_id(session, agent_id)
    if not agent:
        return False
    await session.delete(agent)
    await session.flush()
    return True
