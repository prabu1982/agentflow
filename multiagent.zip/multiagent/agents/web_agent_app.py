"""Web Agent: FastAPI app with A2A + REST. Run standalone (e.g. port 8001)."""
import os
import uuid
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from a2a.schemas import (
    Message,
    Part,
    SendMessageRequest,
    Task,
)
from agents.base_agent import (
    run_steps_stub,
    build_agent_card,
    create_task_response,
)

app = FastAPI(title="Web Agent", version="1.0.0")

# Base URL where this agent is reachable (for Agent Card)
BASE_URL = os.environ.get("WEB_AGENT_BASE_URL", "http://localhost:8001")
AGENT_ID = "WEB"


@app.get("/.well-known/agent-card.json")
async def get_agent_card():
    """A2A: Agent discovery."""
    card = build_agent_card(
        name="Web Agent",
        description="Agent that performs web automation (navigate, click, type, extract).",
        base_url=BASE_URL,
        agent_id=AGENT_ID,
    )
    return card.model_dump(exclude_none=True)


@app.post("/message:send")
async def a2a_send_message(request: Request):
    """A2A: Send message (workflow node with steps). Returns Task or Message."""
    body = await request.json()
    req = SendMessageRequest.model_validate(body)
    msg = req.message
    context_id = msg.contextId or str(uuid.uuid4())

    # Extract workflow node from first part (data or text)
    node_payload = None
    for part in msg.parts:
        if part.data:
            node_payload = part.data
            break
        if part.text:
            import json
            try:
                node_payload = json.loads(part.text)
            except Exception:
                node_payload = {"steps": [], "description": part.text}
            break

    if not node_payload or "steps" not in node_payload:
        return JSONResponse(
            status_code=400,
            content={"error": "Message must contain a workflow node with 'steps'"},
        )

    steps = node_payload.get("steps", [])
    result = run_steps_stub(AGENT_ID, steps)
    task = create_task_response(context_id, result)
    return task.model_dump(exclude_none=True)


@app.get("/tasks/{task_id}")
async def a2a_get_task(task_id: str):
    """A2A: Get task (stub - we don't persist tasks; return 404 for unknown)."""
    return JSONResponse(status_code=404, content={"error": "Task not found or expired"})


# ----- REST alternative -----
@app.post("/execute")
async def rest_execute(request: Request):
    """REST: Execute node. Accepts full node object (dict) with 'steps'; runs steps and returns result."""
    body = await request.json()
    steps = body.get("steps", []) if isinstance(body, dict) else []
    result = run_steps_stub(AGENT_ID, steps)
    return result


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
