"""Base logic for sub-agents: execute steps and return A2A Task/Message."""
import uuid
from typing import Any
from a2a.schemas import (
    Task,
    TaskStatus,
    Message,
    Part,
    Artifact,
    AgentCard,
    AgentInterface,
    AgentCapabilities,
    AgentSkill,
)


def run_steps_stub(agent_name: str, steps: list[dict]) -> dict:
    """
    Stub execution of steps. In production, Web agent would use browser automation,
    Desktop agent would use desktop automation. Here we simulate and return outputs.
    """
    results = []
    for i, step in enumerate(steps):
        action = step.get("action", "unknown")
        step_id = step.get("step_id") or f"step_{i}"
        results.append({
            "step_id": step_id,
            "action": action,
            "status": "completed",
            "output": f"[{agent_name}] simulated {action}",
        })
    return {"steps": results, "agent": agent_name}


def build_agent_card(
    name: str,
    description: str,
    base_url: str,
    agent_id: str,
) -> AgentCard:
    """Build A2A Agent Card for discovery."""
    return AgentCard(
        name=name,
        description=description,
        version="1.0.0",
        supportedInterfaces=[
            AgentInterface(
                url=base_url.rstrip("/"),
                protocolBinding="HTTP+JSON",
                protocolVersion="0.3",
            )
        ],
        capabilities=AgentCapabilities(streaming=False, pushNotifications=False),
        defaultInputModes=["application/json", "text/plain"],
        defaultOutputModes=["application/json", "text/plain"],
        skills=[
            AgentSkill(
                id="execute_steps",
                name="Execute workflow steps",
                description="Runs a list of steps (navigate, click, type, etc.)",
                tags=["workflow", "automation"],
            )
        ],
    )


def create_task_response(context_id: str, result: dict) -> Task:
    """Create A2A Task with COMPLETED state and one artifact (result)."""
    task_id = str(uuid.uuid4())
    artifact = Artifact(
        artifactId=str(uuid.uuid4()),
        name="step_results",
        description="Output from executed steps",
        parts=[Part(data=result, mediaType="application/json")],
    )
    return Task(
        id=task_id,
        contextId=context_id,
        status=TaskStatus(
            state="TASK_STATE_COMPLETED",
            timestamp=__iso_now(),
        ),
        artifacts=[artifact],
        metadata={"result": "ok"},
    )


def __iso_now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
