"""
Orchestrator: reads workflow JSON, looks up agents in registry, invokes them via A2A (or REST).
Uses LangGraph for flow: start_node -> execute node -> next_node until end.
"""
import httpx
from typing import Any, Optional, TypedDict
from sqlalchemy.ext.asyncio import AsyncSession

from langgraph.graph import StateGraph, END

from models.workflow import WorkflowPayload, WorkflowGraph, WorkflowNode
from db import get_agent_by_id
from a2a.client import A2AClient


async def _execute_one_node(
    session: AsyncSession,
    workflow_dict: dict,
    current: str,
    use_a2a: bool,
    pass_agent_response: bool = True,
    previous_agent_responses: Optional[list] = None,
) -> tuple[Optional[str], dict]:
    """
    Execute a single workflow node. Returns (next_node_name, result_dict).
    result_dict is either {"node_id", "agent", "result"} or {"node_id", "error"}.
    When pass_agent_response is True, previous_agent_responses are included in the payload
    so the next agent receives prior agents' outputs.
    """
    nodes = workflow_dict.get("nodes", {})
    node_spec = nodes.get(current)
    if not node_spec:
        return None, {"node_id": current, "error": "node not found"}

    # No-op: nodes with no steps (e.g. end_node) just advance
    steps = node_spec.get("steps", [])
    if not steps:
        next_name = node_spec.get("next_node") or node_spec.get("default_next_node")
        return next_name, {"node_id": current, "agent": node_spec.get("agent"), "result": {"skipped": True, "reason": "no steps"}}

    agent_id = node_spec.get("agent")
    if not agent_id:
        return None, {"node_id": current, "error": "node has no 'agent' attribute"}

    agent_record = await get_agent_by_id(session, agent_id)
    if not agent_record:
        return None, {
            "node_id": current,
            "agent": agent_id,
            "error": f"Agent '{agent_id}' not found in registry. Register via POST /registry/agents.",
        }

    base_url = agent_record.base_url.rstrip("/")
    # Pass the entire node object (from JSON) to the agent in dict format
    node_payload = dict(node_spec)
    node_payload["node_id"] = current
    if pass_agent_response and previous_agent_responses:
        node_payload["previous_agent_responses"] = previous_agent_responses

    try:
        if use_a2a:
            client = A2AClient(base_url)
            out = await client.invoke_steps(node_payload)
        else:
            out = await _rest_invoke(base_url, node_payload)
    except Exception as e:
        return None, {"node_id": current, "agent": agent_id, "error": str(e)}

    next_name = node_spec.get("next_node") or node_spec.get("default_next_node")
    return next_name, {"node_id": current, "agent": agent_id, "result": out}


def _build_workflow_graph(session: AsyncSession, use_a2a: bool, pass_agent_response: bool):
    """Build LangGraph: single node 'execute' that runs one step; conditional edge to next or END."""

    async def execute_node(state: dict) -> dict:
        workflow_dict = state["workflow_dict"]
        current = state["current_node"]
        results = list(state.get("results", []))
        session = state["_session"]
        use_a2a_flag = state.get("use_a2a", True)
        pass_resp = state.get("pass_agent_response", True)
        previous_responses = list(state.get("previous_agent_responses", []))

        next_name, result = await _execute_one_node(
            session,
            workflow_dict,
            current,
            use_a2a_flag,
            pass_agent_response=pass_resp,
            previous_agent_responses=previous_responses if pass_resp else None,
        )
        results.append(result)
        if "error" in result:
            return {"results": results, "current_node": None, "previous_agent_responses": previous_responses}
        # Append this agent's result so the next agent receives it (when pass_agent_response is True)
        next_previous = previous_responses + [{"node_id": current, "agent": result.get("agent"), "result": result.get("result")}]
        if not next_name or next_name not in workflow_dict.get("nodes", {}):
            return {"results": results, "current_node": None, "previous_agent_responses": next_previous}
        return {"results": results, "current_node": next_name, "previous_agent_responses": next_previous}

    def route_after_execute(state: dict) -> str:
        if state.get("current_node"):
            return "execute"
        return END

    class WorkflowState(TypedDict, total=False):
        workflow_dict: dict
        current_node: Optional[str]
        results: list
        previous_agent_responses: list
        _session: Any
        use_a2a: bool
        pass_agent_response: bool

    graph = StateGraph(WorkflowState)
    graph.add_node("execute", execute_node)
    graph.set_entry_point("execute")
    graph.add_conditional_edges("execute", route_after_execute, ["execute", END])
    return graph.compile()


async def execute_workflow(
    session: AsyncSession,
    workflow: WorkflowPayload,
    use_a2a: bool = True,
    raw_workflow_graph: Optional[dict] = None,
    pass_agent_response: bool = True,
) -> dict:
    """
    Execute workflow_graph using LangGraph. For each node: read the node from JSON,
    check the agent attribute, get agent details from DB, pass the entire node object
    (dict) to that agent.
    If raw_workflow_graph is provided (from request body), nodes are taken from it
    so the full node object (all keys) is passed to agents.
    When pass_agent_response is True (default), each agent receives previous_agent_responses
    (list of {node_id, agent, result} from prior nodes) in its payload.
    """
    graph_spec = workflow.workflow_graph
    nodes = graph_spec.nodes
    start = graph_spec.start_node
    if start not in nodes:
        return {"error": f"start_node '{start}' not in workflow_graph.nodes", "results": []}

    if raw_workflow_graph and "nodes" in raw_workflow_graph:
        workflow_dict = {
            "start_node": raw_workflow_graph.get("start_node", start),
            "nodes": dict(raw_workflow_graph["nodes"]),
        }
    else:
        workflow_dict = {
            "start_node": start,
            "nodes": {
                k: {
                    "agent": v.agent,
                    "type": v.type,
                    "description": v.description,
                    "steps": [s.model_dump(exclude_none=True) for s in v.steps],
                    "next_node": v.next_node,
                    "default_next_node": v.default_next_node,
                }
                for k, v in nodes.items()
            },
        }

    compiled = _build_workflow_graph(session, use_a2a, pass_agent_response)
    initial = {
        "workflow_dict": workflow_dict,
        "current_node": start,
        "results": [],
        "previous_agent_responses": [],
        "_session": session,
        "use_a2a": use_a2a,
        "pass_agent_response": pass_agent_response,
    }
    final = await compiled.ainvoke(initial)
    results = final.get("results", [])

    return {
        "workflow_id": getattr(workflow, "procedure_id", None),
        "start_node": start,
        "results": results,
        "completed": not any(r.get("error") for r in results),
    }


async def _rest_invoke(base_url: str, node_payload: dict) -> dict:
    """Call agent via REST POST /execute. Sends the entire node object (dict)."""
    async with httpx.AsyncClient(timeout=60.0) as client:
        r = await client.post(
            f"{base_url}/execute",
            json=node_payload,
            headers={"Content-Type": "application/json"},
        )
        r.raise_for_status()
        return r.json()
