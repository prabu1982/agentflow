"""
Main Orchestrator API: Agent Registry + Workflow execution.
Run: uvicorn main:app --host 0.0.0.0 --port 8000
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from config import get_settings
from models.db_models import init_db, get_async_session, create_tables
from api.registry_api import router as registry_router
from agents.orchestrator import execute_workflow
from models.workflow import WorkflowPayload


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    init_db(settings.registry_db_url)
    await create_tables(settings.registry_db_url)
    yield
    # shutdown: close engine if needed
    from models.db_models import _engine
    if _engine is not None:
        await _engine.dispose()


app = FastAPI(
    title="Multi-Agent Orchestrator",
    description="Orchestrator + Agent Registry. Register agents, then run workflows by passing JSON.",
    version="1.0.0",
    lifespan=lifespan,
)

app.include_router(registry_router)


@app.post("/workflow/execute")
async def workflow_execute(
    body: dict,
    use_a2a: bool = Query(True, description="Use A2A protocol; false = REST /execute"),
    pass_agent_response: bool = Query(
        True,
        description="Pass previous agents' responses to the next agent (previous_agent_responses in payload)",
    ),
    session: AsyncSession = Depends(get_async_session),
):
    """
    Execute a workflow. Pass the workflow JSON as body (same shape as sample_workflow_web_desktop.json).
    Requires workflow_graph with start_node and nodes (each node has agent, steps, next_node).
    Agents must be registered via POST /registry/agents (agent_id = WEB, DESKTOP, etc.).
    Query param use_a2a=true (default) uses A2A protocol; use_a2a=false uses REST /execute.
    Query param pass_agent_response=true (default) sends prior agents' results to each next agent. Can also set "pass_agent_response": false in the request body to override.
    """
    try:
        workflow = WorkflowPayload.model_validate(body)
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Invalid workflow JSON: {e}")
    raw_graph = body.get("workflow_graph")
    # Body can override query param: "pass_agent_response": true/false
    pass_resp = body.get("pass_agent_response", pass_agent_response)
    if not isinstance(pass_resp, bool):
        pass_resp = bool(pass_resp)
    result = await execute_workflow(
        session,
        workflow,
        use_a2a=use_a2a,
        raw_workflow_graph=raw_graph,
        pass_agent_response=pass_resp,
    )
    return result


@app.get("/health")
async def health():
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn
    s = get_settings()
    uvicorn.run(
        "main:app",
        host=s.orchestrator_host,
        port=s.orchestrator_port,
        reload=True,
    )
