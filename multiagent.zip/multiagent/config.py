"""App configuration."""
from functools import lru_cache
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings."""

    # Registry / Orchestrator
    registry_db_url: str = "sqlite+aiosqlite:///./agent_registry.db"
    orchestrator_host: str = "0.0.0.0"
    orchestrator_port: int = 8000

    # Sub-agents (default base URLs when running locally)
    web_agent_base_url: str = "http://localhost:8001"
    desktop_agent_base_url: str = "http://localhost:8002"

    # Use A2A for agent calls; if False, use REST fallback
    use_a2a: bool = True

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache
def get_settings() -> Settings:
    return Settings()
