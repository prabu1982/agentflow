"""A2A protocol data models (simplified from spec for HTTP+JSON binding)."""
from typing import Any, Optional
from pydantic import BaseModel, Field


# ----- Parts & Messages -----
class Part(BaseModel):
    """Content part: text, url, or data."""
    text: Optional[str] = None
    url: Optional[str] = None
    data: Optional[Any] = None
    mediaType: Optional[str] = None
    metadata: Optional[dict] = None
    filename: Optional[str] = None


class Message(BaseModel):
    """A2A Message (user or agent turn)."""
    messageId: str
    role: str = "ROLE_USER"  # ROLE_USER | ROLE_AGENT
    parts: list[Part] = Field(default_factory=list)
    contextId: Optional[str] = None
    taskId: Optional[str] = None
    metadata: Optional[dict] = None
    referenceTaskIds: Optional[list[str]] = None


# ----- Task -----
class TaskStatus(BaseModel):
    """Current status of a task."""
    state: str = "TASK_STATE_UNSPECIFIED"
    message: Optional[Message] = None
    timestamp: Optional[str] = None


class Artifact(BaseModel):
    """Task output artifact."""
    artifactId: str
    name: Optional[str] = None
    description: Optional[str] = None
    parts: list[Part] = Field(default_factory=list)
    metadata: Optional[dict] = None


class Task(BaseModel):
    """A2A Task (unit of work)."""
    id: str
    contextId: str
    status: TaskStatus
    artifacts: list[Artifact] = Field(default_factory=list)
    history: list[Message] = Field(default_factory=list)
    metadata: Optional[dict] = None


# ----- Send Message -----
class SendMessageConfiguration(BaseModel):
    """Options for send message."""
    blocking: bool = True
    historyLength: Optional[int] = None
    acceptedOutputModes: Optional[list[str]] = None


class SendMessageRequest(BaseModel):
    """Request body for POST /message:send."""
    message: Message
    configuration: Optional[SendMessageConfiguration] = None
    metadata: Optional[dict] = None


# ----- Stream response (task or message) -----
class StreamResponse(BaseModel):
    """Wrapper for streaming: exactly one of task, message, statusUpdate, artifactUpdate."""
    task: Optional[Task] = None
    message: Optional[Message] = None
    statusUpdate: Optional[dict] = None
    artifactUpdate: Optional[dict] = None


# ----- Agent Card -----
class AgentInterface(BaseModel):
    """Supported interface (URL + binding)."""
    url: str
    protocolBinding: str = "HTTP+JSON"
    protocolVersion: str = "0.3"
    tenant: Optional[str] = None


class AgentCapabilities(BaseModel):
    """Optional capabilities."""
    streaming: bool = False
    pushNotifications: bool = False
    extendedAgentCard: bool = False


class AgentSkill(BaseModel):
    """Skill description."""
    id: str
    name: str
    description: str
    tags: list[str] = Field(default_factory=list)


class AgentCard(BaseModel):
    """A2A Agent Card (discovery)."""
    name: str
    description: str
    version: str = "1.0.0"
    supportedInterfaces: list[AgentInterface] = Field(default_factory=list)
    capabilities: AgentCapabilities = Field(default_factory=AgentCapabilities)
    defaultInputModes: list[str] = Field(default_factory=lambda: ["application/json", "text/plain"])
    defaultOutputModes: list[str] = Field(default_factory=lambda: ["application/json", "text/plain"])
    skills: list[AgentSkill] = Field(default_factory=list)
