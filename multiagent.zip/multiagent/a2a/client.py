"""A2A client: call remote agents via A2A protocol (HTTP+JSON)."""
import uuid
import httpx
from typing import Any, Optional, Union

from .schemas import (
    AgentCard,
    Message,
    Part,
    Task,
    SendMessageRequest,
    SendMessageConfiguration,
)


class A2AClient:
    """Client to invoke A2A agents (Send Message, Get Task, Get Agent Card)."""

    def __init__(self, base_url: str, timeout: float = 60.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "A2A-Version": "0.3",
        }

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}" if path.startswith("/") else f"{self.base_url}/{path}"

    async def get_agent_card(self) -> AgentCard:
        """GET /.well-known/agent-card.json"""
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            r = await client.get(
                self._url("/.well-known/agent-card.json"),
                headers={"Accept": "application/json", "A2A-Version": "0.3"},
            )
            r.raise_for_status()
            return AgentCard.model_validate(r.json())

    async def send_message(
        self,
        content: Any,
        blocking: bool = True,
        context_id: Optional[str] = None,
    ) -> Union[Task, Message]:
        """
        POST /message:send with a message. content can be str or dict (will be sent as Part).
        Returns Task or Message from response.
        """
        message_id = str(uuid.uuid4())
        if isinstance(content, str):
            parts = [Part(text=content)]
        elif isinstance(content, dict):
            parts = [Part(data=content, mediaType="application/json")]
        else:
            parts = [Part(data=content, mediaType="application/json")]

        msg = Message(
            messageId=message_id,
            role="ROLE_USER",
            parts=parts,
            contextId=context_id,
        )
        req = SendMessageRequest(
            message=msg,
            configuration=SendMessageConfiguration(blocking=blocking),
        )
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            r = await client.post(
                self._url("/message:send"),
                json=req.model_dump(exclude_none=True),
                headers=self._headers,
            )
            r.raise_for_status()
            data = r.json()
        if "id" in data and "contextId" in data and "status" in data:
            return Task.model_validate(data)
        return Message.model_validate(data)

    async def get_task(self, task_id: str, history_length: Optional[int] = None) -> Task:
        """GET /tasks/{id}"""
        url = self._url(f"/tasks/{task_id}")
        params = {}
        if history_length is not None:
            params["historyLength"] = history_length
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            r = await client.get(url, headers=self._headers, params=params or None)
            r.raise_for_status()
            return Task.model_validate(r.json())

    async def invoke_steps(self, node_payload: dict) -> dict:
        """
        Send a workflow node (agent + steps) to the remote agent via A2A.
        node_payload: { "agent": "WEB", "description": "...", "steps": [...], ... }
        Returns a dict with task result: artifacts, status, or parsed response.
        """
        response = await self.send_message(node_payload, blocking=True)
        if isinstance(response, Task):
            state = response.status.state if response.status else ""
            artifacts = []
            for a in response.artifacts:
                for p in a.parts:
                    if p.data is not None:
                        artifacts.append({"artifactId": a.artifactId, "data": p.data})
                    elif p.text:
                        artifacts.append({"artifactId": a.artifactId, "text": p.text})
            return {
                "taskId": response.id,
                "contextId": response.contextId,
                "state": state,
                "artifacts": artifacts,
                "history_length": len(response.history or []),
            }
        # Direct Message response
        out = []
        for p in response.parts:
            if p.data is not None:
                out.append(p.data)
            elif p.text:
                out.append({"text": p.text})
        return {"message": True, "parts": out}
