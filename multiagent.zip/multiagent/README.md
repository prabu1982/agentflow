# Multi-Agent Flow: Orchestrator + Web & Desktop Agents

One **orchestrator** agent and two **sub-agents** (Web, Desktop), all connected via **A2A** (Agent-to-Agent) protocol, with a **REST** option. All agents are exposed as **APIs** (FastAPI). An **Agent Registry API** stores agent info (base URL, etc.) in a database. The user calls the orchestrator with a **workflow JSON**; the orchestrator reads `workflow_graph`, resolves each node’s `agent` from the registry, and invokes the corresponding agent (A2A or REST). Built with **LangGraph** and **FastAPI**.

## Architecture

- **Orchestrator** (port 8000): Registry API + workflow execution. Reads workflow JSON → for each node looks up `agent` in DB → calls that agent via A2A (or REST) with the node’s steps.
- **Web Agent** (port 8001): A2A + REST. Executes web-automation steps (stub implementation).
- **Desktop Agent** (port 8002): A2A + REST. Executes desktop-automation steps (stub implementation).

Agents run **standalone**; communication is via **A2A** (or REST).

## Setup

```bash
cd /Users/prabu_k/Documents/POC/Assistant/multiagent
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Run (3 terminals)

**Terminal 1 – Orchestrator (Registry + workflow execute)**

```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

**Terminal 2 – Web Agent**

```bash
uvicorn agents.web_agent_app:app --host 0.0.0.0 --port 8001
```

**Terminal 3 – Desktop Agent**

```bash
uvicorn agents.desktop_agent_app:app --host 0.0.0.0 --port 8002
```

## Agent Registry API

- **POST /registry/agents** – Register/upsert agent (body: `agent_id`, `name`, `base_url`, `description`, `capabilities`, `metadata`).
- **GET /registry/agents** – List agents.
- **GET /registry/agents/{agent_id}** – Get one agent.
- **PATCH /registry/agents/{agent_id}** – Update agent.
- **DELETE /registry/agents/{agent_id}** – Delete agent.

Example – register Web and Desktop agents:

```bash
curl -X POST http://localhost:8000/registry/agents \
  -H "Content-Type: application/json" \
  -d '{"agent_id":"WEB","name":"Web Agent","base_url":"http://localhost:8001","description":"Web automation"}'

curl -X POST http://localhost:8000/registry/agents \
  -H "Content-Type: application/json" \
  -d '{"agent_id":"DESKTOP","name":"Desktop Agent","base_url":"http://localhost:8002","description":"Desktop automation"}'
```

## Workflow execution

- **POST /workflow/execute** – Body = workflow JSON (see `sample_workflow_web_desktop.json`). Query params: `use_a2a=true` (default) or `use_a2a=false` for REST; `pass_agent_response=true` (default) to pass prior agents’ responses to the next agent.

Example:

```bash
curl -X POST "http://localhost:8000/workflow/execute?use_a2a=true&pass_agent_response=true" \
  -H "Content-Type: application/json" \
  -d @sample_workflow_web_desktop.json
```

The orchestrator will:

1. Read the JSON and `workflow_graph`.
2. Start at `workflow_graph.start_node`.
3. For each node, read `agent`, look it up in the registry, then call that agent (A2A or REST) with the node’s `steps`.
4. Follow `next_node` until there is no next or an error.  
   If `pass_agent_response=true` (default), each agent’s payload includes `previous_agent_responses`: a list of `{node_id, agent, result}` from all prior nodes, so the next agent can use prior outputs.

## A2A protocol (sub-agents)

Each sub-agent exposes:

- **GET /.well-known/agent-card.json** – Agent Card (discovery).
- **POST /message:send** – A2A Send Message (body: `SendMessageRequest` with `message.parts` containing the workflow node, e.g. JSON with `steps`).
- **GET /tasks/{id}** – Get task (stub: 404).

REST option:

- **POST /execute** – Body: `{"steps": [...]}`. Same behavior without A2A.

## Workflow JSON shape

- `workflow_graph.start_node`: entry node id.
- `workflow_graph.nodes`: map of node id → `{ "agent": "WEB"|"DESKTOP"|..., "steps": [...], "next_node": "..." }`.
- Each step: `action`, optional `target`, `value`, `url`, `timeout_ms`, `output_variable`, etc.

See `sample_workflow_web_desktop.json` and `sample_workflow_multi_agent.json`. If a node’s `agent` (e.g. `MasterAgent`, `end_node`) is not in the registry, the run stops and returns an error for that node; you can register a no-op agent or omit such nodes in your workflow.

## Config

- `config.py` / env: `REGISTRY_DB_URL`, `ORCHESTRATOR_HOST`, `ORCHESTRATOR_PORT`, `WEB_AGENT_BASE_URL`, `DESKTOP_AGENT_BASE_URL`, `USE_A2A`.

## Project layout

```
multiagent/
├── main.py                 # Orchestrator app (registry + workflow execute)
├── config.py
├── requirements.txt
├── models/
│   ├── db_models.py        # Agent registry table, async session
│   └── workflow.py        # WorkflowPayload, WorkflowGraph, WorkflowNode
├── db/
│   └── registry.py        # CRUD for agents
├── a2a/
│   ├── schemas.py         # A2A Message, Task, Part, SendMessageRequest, AgentCard
│   └── client.py          # A2AClient (send_message, get_task, get_agent_card)
├── api/
│   └── registry_api.py    # FastAPI router for /registry/agents
├── agents/
│   ├── base_agent.py      # run_steps_stub, build_agent_card, create_task_response
│   ├── web_agent_app.py   # Web agent FastAPI (A2A + REST)
│   ├── desktop_agent_app.py # Desktop agent FastAPI (A2A + REST)
│   └── orchestrator.py    # execute_workflow (LangGraph), A2A/REST invocation
└── sample_workflow_web_desktop.json
```
