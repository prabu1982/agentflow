"""Workflow JSON schema for orchestrator."""
from typing import Any, Optional
from pydantic import BaseModel, Field


class WorkflowStep(BaseModel):
    """Single step in a workflow node."""
    step_id: Optional[str] = None
    action: str
    target: Optional[str] = None
    value: Optional[Any] = None
    url: Optional[str] = None
    timeout_ms: Optional[int] = None
    wait_after_ms: Optional[int] = None
    output_variable: Optional[str] = None
    keys: Optional[list[str]] = None


class WorkflowNode(BaseModel):
    """Node in workflow_graph.nodes."""
    agent: str = Field(..., description="Agent identifier (e.g. WEB, DESKTOP, MasterAgent)")
    type: Optional[str] = None
    description: Optional[str] = None
    steps: list[WorkflowStep] = Field(default_factory=list)
    next_node: Optional[str] = None
    default_next_node: Optional[str] = None


class WorkflowGraph(BaseModel):
    """workflow_graph from the user JSON."""
    start_node: str
    nodes: dict[str, WorkflowNode]


class WorkflowPayload(BaseModel):
    """Full workflow JSON as passed by the user."""
    procedure_id: Optional[str] = None
    version: Optional[str] = None
    description: Optional[str] = None
    workflow_graph: WorkflowGraph
