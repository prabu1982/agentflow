"""Database models for agent registry."""
from datetime import datetime
from sqlalchemy import String, DateTime, Text, JSON
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from typing import AsyncGenerator
import os


class Base(DeclarativeBase):
    pass


class AgentRegistryModel(Base):
    """Stored agent information for discovery and invocation."""

    __tablename__ = "agents"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    agent_id: Mapped[str] = mapped_column(String(128), unique=True, index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    base_url: Mapped[str] = mapped_column(String(512), nullable=False)
    description: Mapped[str] = mapped_column(Text, default="")
    capabilities: Mapped[dict] = mapped_column(JSON, default=dict)  # e.g. {"a2a": true, "rest": true}
    metadata_: Mapped[dict] = mapped_column("metadata", JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# Global engine and session factory (set by init_db)
_engine = None
_async_session_factory = None


def init_db(database_url: str) -> None:
    """Initialize async engine and session factory."""
    global _engine, _async_session_factory
    _engine = create_async_engine(
        database_url,
        echo=os.environ.get("SQL_ECHO", "").lower() in ("1", "true"),
    )
    _async_session_factory = async_sessionmaker(
        _engine, class_=AsyncSession, expire_on_commit=False
    )


async def get_async_session() -> AsyncGenerator[AsyncSession, None]:
    """Dependency: yield async DB session."""
    if _async_session_factory is None:
        raise RuntimeError("init_db() must be called before get_async_session")
    async with _async_session_factory() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
        else:
            await session.commit()
        finally:
            await session.close()


async def create_tables(database_url: str) -> None:
    """Create all tables (call once at startup)."""
    if _engine is None:
        init_db(database_url)
    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
