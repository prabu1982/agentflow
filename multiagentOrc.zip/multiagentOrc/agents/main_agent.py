"""
Main Agent: orchestrates workflow execution using LangGraph-style flow.
Routes nodes to Web Agent or Desktop Agent (via MCP) or handles MasterAgent locally.
Stores every step status in SQLite; on failure stores execution_id.
"""
from __future__ import annotations

import logging
from typing import Any

from langgraph.graph import StateGraph, END

from agents.state import WorkflowState
from db.repository import (
    record_step_start,
    record_step_end,
    update_execution_status,
    create_execution,
)
from db.models import ExecutionStatus, StepStatus
from agents.web_agent import run as web_agent_run
from agents.desktop_agent import run as desktop_agent_run

logger = logging.getLogger(__name__)


def _resolve_next_node(node: dict, context: dict[str, Any]) -> str | None:
    """Determine next node from node config (next_node, default_next_node, or rules)."""
    if node.get("next_node"):
        return node["next_node"]
    if node.get("default_next_node"):
        return node["default_next_node"]
    for rule in node.get("rules") or []:
        # Simple condition check (could be extended with expression eval)
        cond = rule.get("condition", "")
        if cond and rule.get("next_node"):
            return rule["next_node"]
    return None


def _run_master_agent_node(
    execution_id: str,
    node_id: str,
    node: dict,
    context: dict[str, Any],
) -> dict[str, Any]:
    """Handle MasterAgent nodes: no MCP, just record steps and update context."""
    steps = node.get("steps") or []
    result_outputs = {}
    for step in steps:
        step_id = step.get("step_id") or "step"
        record_step_start(execution_id, node_id, step_id, "MasterAgent", step)
        # MasterAgent steps (log, screenshot, etc.) can be no-op or local execution
        try:
            # Placeholder: in production you might run log/screenshot locally
            record_step_end(execution_id, node_id, step_id, StepStatus.COMPLETED, result={})
            out_var = step.get("output_variable")
            if out_var:
                result_outputs[out_var] = {"recorded": True}
        except Exception as e:
            record_step_end(execution_id, node_id, step_id, StepStatus.FAILED, error_message=str(e))
            raise
    return {"outputs": result_outputs}


def _run_web_agent_node(
    execution_id: str,
    node_id: str,
    node: dict,
    context: dict[str, Any],
) -> dict[str, Any]:
    """Delegate to Web Agent (connected to Web MCP Server). Record each step in DB."""
    steps = node.get("steps") or []
    for step in steps:
        step_id = step.get("step_id") or "step"
        record_step_start(execution_id, node_id, step_id, "WEB", step)
    try:
        result = web_agent_run(node_id, steps, context)
        for step in steps:
            step_id = step.get("step_id") or "step"
            record_step_end(execution_id, node_id, step_id, StepStatus.COMPLETED, result=result)
        return result
    except Exception as e:
        for step in steps:
            step_id = step.get("step_id") or "step"
            record_step_end(execution_id, node_id, step_id, StepStatus.FAILED, error_message=str(e))
        raise


def _run_desktop_agent_node(
    execution_id: str,
    node_id: str,
    node: dict,
    context: dict[str, Any],
) -> dict[str, Any]:
    """Delegate to Desktop Agent (connected to Desktop MCP Server). Record each step in DB."""
    steps = node.get("steps") or []
    for step in steps:
        step_id = step.get("step_id") or "step"
        record_step_start(execution_id, node_id, step_id, "DESKTOP", step)
    try:
        result = desktop_agent_run(node_id, steps, context)
        for step in steps:
            step_id = step.get("step_id") or "step"
            record_step_end(execution_id, node_id, step_id, StepStatus.COMPLETED, result=result)
        return result
    except Exception as e:
        for step in steps:
            step_id = step.get("step_id") or "step"
            record_step_end(execution_id, node_id, step_id, StepStatus.FAILED, error_message=str(e))
        raise


def process_node(state: WorkflowState) -> WorkflowState:
    """
    Process the current workflow node: route to Web/Desktop/Master and record steps.
    Updates state with node_result, context, error, and completed/failed_step.
    """
    execution_id = state["execution_id"]
    workflow = state["workflow"]
    current_node_id = state["current_node_id"]
    context = state.get("context") or {}

    graph = workflow.get("workflow_graph") or {}
    nodes = graph.get("nodes") or {}
    node = nodes.get(current_node_id)
    if not node:
        return {**state, "error": f"Unknown node: {current_node_id}", "completed": True}

    agent_type = (node.get("agent") or "MasterAgent").upper()
    if agent_type == "MASTERAGENT":
        agent_type = "MasterAgent"

    steps = node.get("steps")
    # Nodes without steps (logic, verification, etc.): just resolve next
    if not steps:
        next_node = _resolve_next_node(node, context)
        return {
            **state,
            "node_result": {},
            "context": context,
            "current_node_id": next_node or "",
            "completed": next_node is None,
        }

    try:
        if agent_type == "WEB":
            node_result = _run_web_agent_node(execution_id, current_node_id, node, context)
        elif agent_type == "DESKTOP":
            node_result = _run_desktop_agent_node(execution_id, current_node_id, node, context)
        else:
            node_result = _run_master_agent_node(execution_id, current_node_id, node, context)

        # Merge outputs into context (e.g. output_variable from steps)
        if isinstance(node_result.get("outputs"), dict):
            context = {**context, **node_result["outputs"]}
        next_node = _resolve_next_node(node, context)
        return {
            **state,
            "node_result": node_result,
            "context": context,
            "current_node_id": next_node or "",
            "completed": next_node is None,
        }
    except Exception as e:
        logger.exception("Node %s failed", current_node_id)
        update_execution_status(
            execution_id,
            ExecutionStatus.FAILED,
            error_message=str(e),
            failed_at_step_id=current_node_id,
        )
        return {
            **state,
            "error": str(e),
            "failed_step": {"node_id": current_node_id, "agent_type": agent_type},
            "completed": True,
        }


def route_after_process(state: WorkflowState) -> str:
    """Next: end or continue to next node."""
    if state.get("completed"):
        return "end"
    return "process"


def run_workflow(workflow_input: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    """
    Execute the full workflow. Creates execution, runs graph, returns (execution_id, result).
    On failure, execution_id is stored in DB with status FAILED and failed_at_step_id.
    """
    procedure_id = workflow_input.get("procedure_id") or "default"
    execution_id = create_execution(procedure_id, workflow_input)

    graph = workflow_input.get("workflow_graph") or {}
    start_node = graph.get("start_node")
    if not start_node:
        update_execution_status(execution_id, ExecutionStatus.FAILED, error_message="Missing workflow_graph.start_node")
        return execution_id, {"status": "failed", "error": "Missing workflow_graph.start_node"}

    # Build and run LangGraph: process_node -> route -> process_node or end
    builder = StateGraph(WorkflowState)
    builder.add_node("process", process_node)
    builder.set_entry_point("process")
    builder.add_conditional_edges("process", route_after_process, {"process": "process", "end": END})
    graph_app = builder.compile()

    initial: WorkflowState = {
        "execution_id": execution_id,
        "procedure_id": procedure_id,
        "workflow": workflow_input,
        "current_node_id": start_node,
        "context": {},
        "completed": False,
    }

    try:
        final = None
        for event in graph_app.stream(initial):
            for v in event.values():
                final = v
        if final and final.get("error"):
            return execution_id, {"status": "failed", "error": final["error"], "failed_step": final.get("failed_step")}
        update_execution_status(execution_id, ExecutionStatus.COMPLETED)
        return execution_id, {"status": "completed", "execution_id": execution_id, "context": final.get("context") or {}}
    except Exception as e:
        update_execution_status(
            execution_id,
            ExecutionStatus.FAILED,
            error_message=str(e),
            failed_at_step_id=getattr(e, "failed_node", None),
        )
        return execution_id, {"status": "failed", "error": str(e), "execution_id": execution_id}
