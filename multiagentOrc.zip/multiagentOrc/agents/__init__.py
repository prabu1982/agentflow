# Agents: Main Agent, Web Agent, Desktop Agent

from agents.main_agent import run_workflow
from agents.web_agent import NAME as WEB_AGENT_NAME, run as web_agent_run
from agents.desktop_agent import NAME as DESKTOP_AGENT_NAME, run as desktop_agent_run

__all__ = [
    "run_workflow",
    "WEB_AGENT_NAME",
    "DESKTOP_AGENT_NAME",
    "web_agent_run",
    "desktop_agent_run",
]
