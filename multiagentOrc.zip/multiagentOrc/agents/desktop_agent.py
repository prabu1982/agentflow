"""
Desktop Agent – sub-agent connected to the Desktop MCP Server.
Executes workflow steps that require desktop automation (launch app, keystrokes, windows, etc.).
"""
from __future__ import annotations

import logging
from typing import Any

from mcp.desktop_client import execute_desktop_steps_sync

logger = logging.getLogger(__name__)

# Agent identity for logging and discovery
NAME = "Desktop Agent"
DESCRIPTION = "Executes desktop automation steps via the Desktop MCP Server (launch app, type, keys, screenshot, etc.)."


def run(node_id: str, steps: list[dict], context: dict[str, Any]) -> dict[str, Any]:
    """
    Run this agent: send steps to the Desktop MCP Server and return the result.
    Called by the Main Agent when a workflow node has agent type "DESKTOP".
    """
    logger.info("%s executing node %s (%d steps)", NAME, node_id, len(steps))
    result = execute_desktop_steps_sync(node_id, steps, context)
    logger.info("%s completed node %s", NAME, node_id)
    return result
