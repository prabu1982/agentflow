"""Shared state for the Main Agent graph."""
from typing import Any
from typing_extensions import TypedDict


class WorkflowState(TypedDict, total=False):
    """State passed through the Main Agent graph."""

    execution_id: str
    procedure_id: str
    workflow: dict[str, Any]
    current_node_id: str
    node_result: dict[str, Any]
    context: dict[str, Any]  # accumulated variables for steps (e.g. output_variable)
    error: str
    failed_step: dict[str, Any]
    completed: bool
