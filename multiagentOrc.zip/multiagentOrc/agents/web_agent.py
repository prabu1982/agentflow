"""
Web Agent – sub-agent connected to the Web MCP Server.
Executes workflow steps that require browser/web automation (navigate, click, type, etc.).
"""
from __future__ import annotations

import logging
from typing import Any

from mcp.web_client import execute_web_steps_sync

logger = logging.getLogger(__name__)

# Agent identity for logging and discovery
NAME = "Web Agent"
DESCRIPTION = "Executes web automation steps via the Web MCP Server (navigate, click, type, extract, etc.)."


def run(node_id: str, steps: list[dict], context: dict[str, Any]) -> dict[str, Any]:
    """
    Run this agent: send steps to the Web MCP Server and return the result.
    Called by the Main Agent when a workflow node has agent type "WEB".
    """
    logger.info("%s executing node %s (%d steps)", NAME, node_id, len(steps))
    result = execute_web_steps_sync(node_id, steps, context)
    logger.info("%s completed node %s", NAME, node_id)
    return result
