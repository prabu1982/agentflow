"""Repository for executions and steps."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from uuid import uuid4

from db.database import get_connection
from db.models import ExecutionStatus, StepStatus


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def create_execution(procedure_id: str, workflow_input: dict) -> str:
    conn = get_connection()
    execution_id = str(uuid4())
    now = utc_now()
    conn.execute(
        """INSERT INTO executions (id, procedure_id, status, workflow_input, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (execution_id, procedure_id, ExecutionStatus.RUNNING.value, json.dumps(workflow_input), now, now),
    )
    conn.commit()
    return execution_id


def update_execution_status(
    execution_id: str,
    status: ExecutionStatus,
    error_message: str | None = None,
    failed_at_step_id: str | None = None,
) -> None:
    conn = get_connection()
    conn.execute(
        """UPDATE executions SET status = ?, error_message = ?, failed_at_step_id = ?, updated_at = ?
           WHERE id = ?""",
        (status.value, error_message, failed_at_step_id, utc_now(), execution_id),
    )
    conn.commit()


def record_step_start(execution_id: str, node_id: str, step_id: str, agent_type: str, payload: dict | None) -> None:
    conn = get_connection()
    now = utc_now()
    conn.execute(
        """INSERT INTO steps (execution_id, node_id, step_id, agent_type, status, payload, result, error_message, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, NULL, NULL, ?, ?)""",
        (execution_id, node_id, step_id, agent_type, StepStatus.RUNNING.value, json.dumps(payload) if payload else None, now, now),
    )
    conn.commit()


def record_step_end(
    execution_id: str,
    node_id: str,
    step_id: str,
    status: StepStatus,
    result: dict | None = None,
    error_message: str | None = None,
) -> None:
    conn = get_connection()
    now = utc_now()
    # Update the most recent step row matching (execution_id, node_id, step_id) with RUNNING
    conn.execute(
        """UPDATE steps SET status = ?, result = ?, error_message = ?, updated_at = ?
           WHERE execution_id = ? AND node_id = ? AND step_id = ? AND status = ?""",
        (status.value, json.dumps(result) if result else None, error_message, now, execution_id, node_id, step_id, StepStatus.RUNNING.value),
    )
    conn.commit()


def get_execution(execution_id: str) -> dict | None:
    conn = get_connection()
    row = conn.execute("SELECT * FROM executions WHERE id = ?", (execution_id,)).fetchone()
    if not row:
        return None
    return {
        "id": row["id"],
        "procedure_id": row["procedure_id"],
        "status": row["status"],
        "workflow_input": json.loads(row["workflow_input"]) if row["workflow_input"] else {},
        "error_message": row["error_message"],
        "failed_at_step_id": row["failed_at_step_id"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def list_executions(limit: int = 50, status: str | None = None) -> list[dict]:
    conn = get_connection()
    if status:
        rows = conn.execute(
            "SELECT * FROM executions WHERE status = ? ORDER BY created_at DESC LIMIT ?",
            (status, limit),
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM executions ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
    return [
        {
            "id": r["id"],
            "procedure_id": r["procedure_id"],
            "status": r["status"],
            "error_message": r["error_message"],
            "failed_at_step_id": r["failed_at_step_id"],
            "created_at": r["created_at"],
            "updated_at": r["updated_at"],
        }
        for r in rows
    ]


def get_steps_for_execution(execution_id: str) -> list[dict]:
    conn = get_connection()
    rows = conn.execute("SELECT * FROM steps WHERE execution_id = ? ORDER BY id", (execution_id,)).fetchall()
    return [
        {
            "id": r["id"],
            "node_id": r["node_id"],
            "step_id": r["step_id"],
            "agent_type": r["agent_type"],
            "status": r["status"],
            "payload": json.loads(r["payload"]) if r["payload"] else None,
            "result": json.loads(r["result"]) if r["result"] else None,
            "error_message": r["error_message"],
            "created_at": r["created_at"],
            "updated_at": r["updated_at"],
        }
        for r in rows
    ]
