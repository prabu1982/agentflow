"""SQLite schema and status enums for workflow executions."""
from __future__ import annotations

from enum import Enum
from dataclasses import dataclass
from typing import Any


class ExecutionStatus(str, Enum):
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class StepStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class Execution:
    id: str
    procedure_id: str
    status: ExecutionStatus
    workflow_input: dict[str, Any]
    created_at: str
    updated_at: str
    error_message: str | None = None
    failed_at_step_id: str | None = None


@dataclass
class StepRecord:
    id: int | None
    execution_id: str
    node_id: str
    step_id: str
    agent_type: str
    status: StepStatus
    payload: str | None
    result: str | None
    error_message: str | None
    created_at: str
    updated_at: str
