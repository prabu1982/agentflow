"""SQLite connection and table creation."""
from __future__ import annotations

import sqlite3
from pathlib import Path

from app.config import get_settings

_conn: sqlite3.Connection | None = None


def _db_path() -> Path:
    path = Path(get_settings().database_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def get_connection() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        _conn = sqlite3.connect(str(_db_path()), check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        init_db()
    return _conn


def init_db() -> None:
    conn = get_connection()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS executions (
            id TEXT PRIMARY KEY,
            procedure_id TEXT NOT NULL,
            status TEXT NOT NULL,
            workflow_input TEXT,
            error_message TEXT,
            failed_at_step_id TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS steps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            execution_id TEXT NOT NULL,
            node_id TEXT NOT NULL,
            step_id TEXT NOT NULL,
            agent_type TEXT NOT NULL,
            status TEXT NOT NULL,
            payload TEXT,
            result TEXT,
            error_message TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (execution_id) REFERENCES executions(id)
        );
        CREATE INDEX IF NOT EXISTS idx_steps_execution ON steps(execution_id);
        CREATE INDEX IF NOT EXISTS idx_executions_status ON executions(status);
    """)
    conn.commit()


def close_db() -> None:
    global _conn
    if _conn is not None:
        _conn.close()
        _conn = None
