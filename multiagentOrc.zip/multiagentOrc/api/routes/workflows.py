"""REST API for workflow execution: POST with JSON, list/get executions."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException

from agents.main_agent import run_workflow
from agents.web_agent import NAME as WEB_AGENT_NAME, DESCRIPTION as WEB_AGENT_DESCRIPTION
from agents.desktop_agent import NAME as DESKTOP_AGENT_NAME, DESCRIPTION as DESKTOP_AGENT_DESCRIPTION
from db.repository import get_execution, list_executions, get_steps_for_execution

router = APIRouter()


@router.get("/agents")
def list_agents():
    """List sub-agents: Web Agent (Web MCP) and Desktop Agent (Desktop MCP)."""
    return {
        "main_agent": "Main Workflow Agent",
        "sub_agents": [
            {"name": WEB_AGENT_NAME, "description": WEB_AGENT_DESCRIPTION, "agent_type": "WEB", "mcp": "Web MCP Server"},
            {"name": DESKTOP_AGENT_NAME, "description": DESKTOP_AGENT_DESCRIPTION, "agent_type": "DESKTOP", "mcp": "Desktop MCP Server"},
        ],
    }


@router.post("/workflows/execute")
def execute_workflow(workflow: dict):
    """
    Execute a workflow from JSON body (e.g. from UI or Postman).
    Returns execution_id and status. Each step status is stored in SQLite.
    On failure, execution is stored with status FAILED and failed_at_step_id.
    """
    try:
        execution_id, result = run_workflow(workflow)
        return {"execution_id": execution_id, **result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/executions")
def list_executions_route(limit: int = 50, status: str | None = None):
    """List workflow executions (optionally filter by status)."""
    return list_executions(limit=limit, status=status)


@router.get("/executions/{execution_id}")
def get_execution_route(execution_id: str):
    """Get one execution by id (includes steps if needed)."""
    ex = get_execution(execution_id)
    if not ex:
        raise HTTPException(status_code=404, detail="Execution not found")
    steps = get_steps_for_execution(execution_id)
    return {**ex, "steps": steps}
