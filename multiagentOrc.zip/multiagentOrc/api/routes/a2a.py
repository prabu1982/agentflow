"""
A2A protocol support for Main Agent onboarding.
Exposes agent card at /.well-known/agent-card.json and message/send (JSON-RPC) to run workflows.
When a2a-sdk is installed (Python 3.10+), use full SDK; otherwise minimal implementation below.
"""
import json
import logging
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from app.config import get_settings
from agents.main_agent import run_workflow

logger = logging.getLogger(__name__)

router = APIRouter()


def _agent_card() -> dict:
    """Build A2A Agent Card for discovery/onboarding."""
    settings = get_settings()
    return {
        "name": settings.a2a_agent_name,
        "description": "Multi-agent workflow orchestrator. Sub-agents: Web Agent (web MCP), Desktop Agent (desktop MCP). Accepts workflow JSON and executes steps, storing status in SQLite.",
        "url": f"{settings.a2a_base_url.rstrip('/')}/.well-known/agent-card.json",
        "capabilities": {
            "streaming": False,
            "pushNotifications": False,
        },
        "skills": [
            {
                "id": "execute_workflow",
                "name": "Execute Workflow",
                "description": "Run a multi-agent workflow from JSON. Message parts may contain workflow JSON (procedure_id, workflow_graph with nodes and agent types WEB/DESKTOP/MasterAgent).",
            }
        ],
    }


@router.get("/.well-known/agent-card.json")
def get_agent_card():
    """A2A discovery: return agent card for onboarding."""
    return _agent_card()


@router.post("/rpc")
async def a2a_jsonrpc(request: Request):
    """
    A2A JSON-RPC endpoint: message/send with workflow in message.parts.
    Body: { "jsonrpc": "2.0", "id": "<id>", "method": "message/send", "params": { "message": { "role": "user", "parts": [ { "kind": "text", "text": "<workflow JSON string>" } ] } } }
    """
    try:
        body = await request.json()
    except Exception as e:
        return JSONResponse(
            status_code=400,
            content={"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": str(e)}},
        )
    req_id = body.get("id")
    method = body.get("method")
    params = body.get("params") or {}

    if method != "message/send":
        return JSONResponse(
            content={
                "jsonrpc": "2.0",
                "id": req_id,
                "error": {"code": -32601, "message": f"Method not supported: {method}. Use message/send with workflow JSON in message.parts[].text."},
            },
        )

    message = params.get("message") or {}
    parts = message.get("parts") or []
    workflow_json_str = None
    for part in parts:
        if part.get("kind") == "text" and part.get("text"):
            workflow_json_str = part["text"]
            break
    if not workflow_json_str:
        return JSONResponse(
            content={
                "jsonrpc": "2.0",
                "id": req_id,
                "error": {"code": -32602, "message": "Invalid params: message.parts must contain a text part with workflow JSON."},
            },
        )
    try:
        workflow = json.loads(workflow_json_str)
    except json.JSONDecodeError as e:
        return JSONResponse(
            content={"jsonrpc": "2.0", "id": req_id, "error": {"code": -32602, "message": f"Invalid workflow JSON: {e}"}},
        )
    try:
        execution_id, result = run_workflow(workflow)
        response_text = json.dumps({"execution_id": execution_id, **result})
    except Exception as e:
        logger.exception("Workflow execution failed")
        response_text = json.dumps({"status": "error", "message": str(e)})
    return JSONResponse(
        content={
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "message": {
                    "role": "agent",
                    "parts": [{"kind": "text", "text": response_text}],
                    "messageId": req_id or "a2a-response",
                }
            },
        },
    )
