"""MCP client for Web Agent: connects to Web MCP Server to execute web steps."""
import json
import logging
from typing import Any

from app.config import get_settings

logger = logging.getLogger(__name__)


async def execute_web_steps(node_id: str, steps: list[dict], context: dict[str, Any]) -> dict[str, Any]:
    """
    Send steps to the Web MCP Server (via Web Agent). Returns result dict or raises.
    If web_mcp_url is not set, returns a stub success for development.
    """
    settings = get_settings()
    if not settings.web_mcp_url:
        logger.warning("Web MCP URL not configured; returning stub success.")
        return {"status": "ok", "message": "Web steps (stub)", "outputs": {}}

    # TODO: Use MCP ClientSession with SSE transport to call settings.web_mcp_url
    # and invoke the appropriate tool (e.g. execute_steps) with steps + context.
    # For now, stub:
    try:
        # When integrating: async with sse_client(settings.web_mcp_url) as (read, write):
        #     session = ClientSession(read, write); await session.initialize();
        #     result = await session.call_tool("execute_steps", {"steps": steps, "context": context})
        return {"status": "ok", "message": "Web MCP not connected", "outputs": {}}
    except Exception as e:
        logger.exception("Web MCP execution failed")
        raise RuntimeError(f"Web Agent MCP failed: {e}") from e


def execute_web_steps_sync(node_id: str, steps: list[dict], context: dict[str, Any]) -> dict[str, Any]:
    """Synchronous wrapper for execute_web_steps."""
    import asyncio
    return asyncio.run(execute_web_steps(node_id, steps, context))
