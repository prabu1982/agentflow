"""MCP client for Desktop Agent: connects to Desktop MCP Server to execute desktop steps."""
import logging
from typing import Any

from app.config import get_settings

logger = logging.getLogger(__name__)


async def execute_desktop_steps(node_id: str, steps: list[dict], context: dict[str, Any]) -> dict[str, Any]:
    """
    Send steps to the Desktop MCP Server (via Desktop Agent). Returns result dict or raises.
    If desktop_mcp_url is not set, returns a stub success for development.
    """
    settings = get_settings()
    if not settings.desktop_mcp_url:
        logger.warning("Desktop MCP URL not configured; returning stub success.")
        return {"status": "ok", "message": "Desktop steps (stub)", "outputs": {}}

    # TODO: Use MCP ClientSession with SSE transport to call settings.desktop_mcp_url
    # and invoke the appropriate tool (e.g. execute_steps) with steps + context.
    try:
        return {"status": "ok", "message": "Desktop MCP not connected", "outputs": {}}
    except Exception as e:
        logger.exception("Desktop MCP execution failed")
        raise RuntimeError(f"Desktop Agent MCP failed: {e}") from e


def execute_desktop_steps_sync(node_id: str, steps: list[dict], context: dict[str, Any]) -> dict[str, Any]:
    """Synchronous wrapper for execute_desktop_steps."""
    import asyncio
    return asyncio.run(execute_desktop_steps(node_id, steps, context))
