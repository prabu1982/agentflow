# Multi-Agent Workflow Orchestrator

One **Main Agent** that orchestrates workflow execution, with two sub-agents: **Web Agent** (connected to a Web MCP Server) and **Desktop Agent** (connected to a Desktop MCP Server). The Main Agent is exposed as an API and supports the **A2A protocol** for onboarding.

## Tech Stack

- **LangGraph** – Main Agent and routing (Web / Desktop / MasterAgent)
- **A2A protocol** – Main Agent discovery and invocation (agent card + `message/send`)
- **FastAPI** – REST API (execute workflow, list/get executions)
- **Fast MCP** – MCP client integration for Web and Desktop agents (stub clients included; wire to real MCP servers via `WEB_MCP_URL` / `DESKTOP_MCP_URL`)
- **SQLite** – Execution and step status storage

## Project Structure

```
multiagentOrc/
├── app/
│   ├── config.py          # Settings (DB, MCP URLs, A2A)
│   └── main.py            # FastAPI app, lifespan, agent card at /.well-known
├── api/
│   └── routes/
│       ├── workflows.py   # POST /api/workflows/execute, GET /api/executions
│       └── a2a.py         # A2A: agent card, JSON-RPC message/send at /a2a
├── agents/
│   ├── state.py           # WorkflowState for LangGraph
│   ├── main_agent.py      # Main Agent: graph, routing, step recording
│   ├── web_agent.py       # Web Agent – sub-agent connected to Web MCP Server
│   └── desktop_agent.py  # Desktop Agent – sub-agent connected to Desktop MCP Server
├── db/
│   ├── database.py        # SQLite init and connection
│   ├── models.py         # ExecutionStatus, StepStatus, dataclasses
│   └── repository.py     # create_execution, record_step_*, get/list
├── mcp/
│   ├── web_client.py     # Web Agent MCP client (execute_web_steps)
│   └── desktop_client.py # Desktop Agent MCP client (execute_desktop_steps)
├── data/                 # Created at runtime: workflow_executions.db
├── requirements.txt
├── instructions.txt
├── sample_workflow_multi_agent.json
└── README.md
```

## Setup

```bash
cd multiagentOrc
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Optional: set Web/Desktop MCP server URLs (otherwise stub responses are used):

```bash
export WEB_MCP_URL=http://localhost:9001
export DESKTOP_MCP_URL=http://localhost:9002
```

## Run

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

- **API docs:** http://localhost:8000/docs  
- **Agent card (A2A onboarding):** http://localhost:8000/.well-known/agent-card.json  

## API Usage

### 1. Execute workflow (Postman / UI)

**POST** `/api/workflows/execute`  
Body: JSON workflow (e.g. from `sample_workflow_multi_agent.json` or a minimal graph).

- **Minimal example:**

```json
{
  "procedure_id": "minimal_demo",
  "workflow_graph": {
    "start_node": "start",
    "nodes": {
      "start": {
        "agent": "MasterAgent",
        "type": "sequence",
        "steps": [{ "step_id": "s1", "action": "log", "value": "Hello" }],
        "next_node": "end_node"
      },
      "end_node": {
        "agent": "MasterAgent",
        "steps": [],
        "next_node": null
      }
    }
  }
}
```

Response: `{ "execution_id": "<uuid>", "status": "completed", ... }`.  
On failure: execution is stored with `status: "failed"` and `failed_at_step_id` (see 3.4 in instructions).

### 2. List agents (Main + Web + Desktop)

**GET** `/api/agents`  
Returns the Main Agent and sub-agents (Web Agent, Desktop Agent) with names, descriptions, and MCP binding.

### 3. List executions

**GET** `/api/executions?limit=50&status=failed`  

### 4. Get one execution (with steps)

**GET** `/api/executions/{execution_id}`  

Returns execution plus all step records (status per step stored in SQLite as per 3.3).

### 5. A2A onboarding and invocation

- **Discovery:** `GET /.well-known/agent-card.json` – agent name, description, capabilities, skills.
- **Invoke:** `POST /a2a/rpc` – JSON-RPC `message/send` with workflow JSON in `message.parts[].text`.

Example:

```json
{
  "jsonrpc": "2.0",
  "id": "1",
  "method": "message/send",
  "params": {
    "message": {
      "role": "user",
      "parts": [
        { "kind": "text", "text": "{\"procedure_id\":\"a2a_run\",\"workflow_graph\":{\"start_node\":\"n1\",\"nodes\":{\"n1\":{\"agent\":\"MasterAgent\",\"steps\":[{\"step_id\":\"s1\",\"action\":\"log\"}],\"next_node\":null}}}" }
      ]
    }
  }
}
```

Response: `result.message.parts[0].text` contains `{"execution_id":"...","status":"completed",...}`.

## Behavior (per instructions)

1. **Main Agent** uses A2A (agent card + `message/send`) and is callable from UI/Postman.
2. **Input:** JSON workflow with `workflow_graph.nodes` and `workflow_graph.start_node`.
3. **Routing by agent type:**
   - **Web Agent** → steps sent to Web Agent (MCP client → Web MCP Server).
   - **Desktop Agent** → steps sent to Desktop Agent (MCP client → Desktop MCP Server).
   - **MasterAgent** → handled in Main Agent (no MCP); logic/sequence nodes supported.
4. **SQLite:** Each step status is stored; on any step failure, the execution is stored with `status: failed` and `failed_at_step_id` (execution id is always stored).
5. **Folder structure:** As above (app, api, agents, db, mcp).
6. **Onboarding:** A2A agent card at `/.well-known/agent-card.json` and `message/send` at `/a2a/rpc`.

## Optional: Full A2A SDK

For Python 3.10+, you can use the official A2A SDK for full task/streaming support:

```bash
pip install "a2a-sdk[http-server]"
```

Then replace or extend `api/routes/a2a.py` with `A2AFastAPIApplication.add_routes_to_app()` and a custom `AgentExecutor` that calls `run_workflow()` and enqueues a `Message`/`Task`.
