"""Application configuration."""
from pathlib import Path
from typing import Optional

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """App settings from env or defaults."""

    app_name: str = "Multi-Agent Workflow Orchestrator"
    debug: bool = False
    # Database
    database_url: str = "sqlite:///./data/workflow_executions.db"
    database_path: str = "data/workflow_executions.db"  # for sync SQLite
    # MCP endpoints (sub-agents); override via env
    web_mcp_url: Optional[str] = None
    desktop_mcp_url: Optional[str] = None
    # A2A
    a2a_base_url: str = "http://localhost:8000"
    a2a_agent_name: str = "Main Workflow Agent"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


def get_settings() -> Settings:
    return Settings()
