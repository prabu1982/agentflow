"""FastAPI application entry: REST API + A2A endpoints."""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from api.routes import workflows, a2a
from db.database import init_db, close_db


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize DB on startup, close on shutdown."""
    init_db()
    yield
    close_db()


def _agent_card_dict() -> dict:
    settings = get_settings()
    return {
        "name": settings.a2a_agent_name,
        "description": "Multi-agent workflow orchestrator. Sub-agents: Web Agent (web MCP), Desktop Agent (desktop MCP). Accepts workflow JSON and executes steps, storing status in SQLite.",
        "url": f"{settings.a2a_base_url.rstrip('/')}/.well-known/agent-card.json",
        "capabilities": {"streaming": False, "pushNotifications": False},
        "skills": [
            {"id": "execute_workflow", "name": "Execute Workflow", "description": "Run a multi-agent workflow from JSON (procedure_id, workflow_graph with agent types WEB/DESKTOP/MasterAgent)."},
        ],
    }


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title=settings.app_name,
        version="1.0.0",
        lifespan=lifespan,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.include_router(workflows.router, prefix="/api", tags=["workflows"])
    app.include_router(a2a.router, prefix="/a2a", tags=["a2a"])

    # A2A discovery: standard path for agent card (onboarding)
    @app.get("/.well-known/agent-card.json")
    def well_known_agent_card():
        return _agent_card_dict()

    return app


app = create_app()
